import java.util.Scanner;
import java.util.ArrayList;
/**
 * Write a description of class Main here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Main
{
    public static void main(String[] args)
    {
        //create object arraylist & list for todolist and status
        ArrayList<String> altodolist = new ArrayList<String>();
        ArrayList<String> alstatus = new ArrayList<String>();
        //tadinya array kosong tapi jadi bikin object karena mau input size arraylist, padahal harusnya variabel?
        //karena disini array harus fixed valuenya
        //kenapa harus buat local variabel seperti ini? kapan harus buat atau kapan tidak perlu?
        String[] todolist = new String[altodolist.size()];
        String[] status = new String[alstatus.size()];
        
        //create object todolistapp & add initial value --> todolist, status
        Notes todolistapp = new Notes(todolist,status);
        
        //create object for input keyboard
        Scanner inputint = new Scanner(System.in);
        Scanner inputstr = new Scanner(System.in);
        
        boolean mainMenu = true;
        while(mainMenu == true){
           System.out.println("");
           System.out.println("-----------------------");
           System.out.println("Welcome to ToDoList App");
           System.out.println("-----------------------");
           System.out.println("");
           System.out.println("Here's our menu : ");
           System.out.println("1. Add new ToDoList");
           System.out.println("2. Show your ToDoList");
           System.out.println("3. Mark as Done (v) your ToDoList");
           System.out.println("4. Quit");
           System.out.println("Which option do you want to choose? : ");
           int option = inputint.nextInt();
        
           switch(option){
               case 1:
                System.out.println("");
                System.out.println("----------------");
                System.out.println("Add new ToDoList");
                System.out.println("----------------");
                System.out.println("");
                System.out.println("Input your ToDoList : ");
                String newtodolist = inputstr.nextLine();
                
                //put newtodolist into arraylist
                
                //add item arraylist and convert to array
                altodolist.add(newtodolist);
                todolist = altodolist.toArray(todolist);
                //System.out.println(todolist[0]);
                //kenapa berhasil? jadi bener isinya array String?
                todolistapp.addList(todolist);
                    
                alstatus.add("x");
                status = alstatus.toArray(status);
                //System.out.println(status[0]);
                todolistapp.addStatus(status);
                    
                System.out.println("Processing... done");
                todolistapp.pressEnterKeyToContinue();
                
                break;
                
               case 2:
                if(todolist.length == 0){
                    System.out.println("Your ToDoList is empty");
                    todolistapp.pressEnterKeyToContinue();
                }else{
                    System.out.println("Your ToDoList : ");
                    for(int i=0; i<todolist.length; i++){
                        int number = i+1;
                        System.out.println("ToDoList " + number + " : " + todolistapp.showList()[i] + " --> " + todolistapp.showStatus()[i]);
                    }
                    todolistapp.pressEnterKeyToContinue();
                }
                
                break;
                
               case 3:
                if(todolist.length == 0){
                    System.out.println("Your ToDoList is empty, nothing to update");
                    todolistapp.pressEnterKeyToContinue();
                }else{
                    System.out.println("Which one of your ToDoList that has been done?");
                    for(int i=0; i<todolist.length; i++){
                        int number = i+1;
                        System.out.println("ToDoList " + number + " : " + todolistapp.showList()[i] + " --> " + todolistapp.showStatus()[i]);
                    }
                    System.out.println("Please input the number : ");
                    option = inputint.nextInt();
                    
                    if(option>0 && option<=todolist.length){
                        //code update status
                        int optionindex = option-1;
                        status[optionindex] = "v";
                        todolistapp.updateStatus(status);
                        System.out.println("ToDoList number " + option + " has been updated");
                    }else{
                        System.out.println("Your ToDoList selection is not exist! Please select another option");
                    }
                }
                
                break;
                
               case 4:
                System.out.println("Exiting ToDoList Application...");
                System.exit(0);
                break;
               
               default:
                System.out.println("This is not a valid Menu Option! Please select another option");
                break;
            }
        }
    }
}
