
/**
 * Write a description of class Notes here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Notes
{
    // instance variables - replace the example below with your own
    private String[] todolist;
    private String[] status;

    /**
     * Constructor for objects of class Notes
     */
    public Notes(String[] todolist, String[] status)
    {
        // initialise instance variables
        this.todolist = todolist;
        this.status = status;
    }

    public String[] showList(){
        return todolist;
    }
    
    public String[] showStatus(){
        return status;
    }
    
    public void addList(String[] todolist){
        this.todolist = todolist;
    }
    
    public void addStatus(String[] status){
        this.status = status;
    }
    
    public void updateStatus(String[] status){
        this.status = status;
    }
    
    public void pressEnterKeyToContinue()
    { 
        System.out.println("Press Enter key to continue...");
        try
        {
            System.in.read();
        }  
        catch(Exception e)
        {}  
    }
}
