import java.util.*;

public class Main
{
    public static void main(String[] args)
    {
        GistItemList gistitemlist = new GistItemList();
        Scanner input = new Scanner(System.in);
        
        while(true){
            System.out.println("");
            System.out.println("Menu");
            System.out.println("1. Create Gist");
            System.out.println("2. Edit Gist");
            System.out.println("3. Delete Gist");
            System.out.println("4. Show Gist(s)");
            System.out.println("5. Exit App");
            System.out.println("Please input option : ");
            int option = input.nextInt();
            input.nextLine();

            switch(option){
                case 1:
                    System.out.println("");
                    System.out.println("===========");
                    System.out.println("Create Gist");
                    System.out.println("===========");
                    System.out.println("Please input your Gist : ");
                    gistitemlist.addGist(input.nextLine());
                    System.out.println("Success create gist");
                    break;
                    
                case 2:
                    System.out.println("");
                    System.out.println("=========");
                    System.out.println("Edit Gist");
                    System.out.println("=========");
                    System.out.println("Which gist do you want to edit : ");
                    gistitemlist.showGist();
                    int itemnum = input.nextInt();

                    System.out.println("Please input new name : ");
                    input.nextLine();
                    String newname = input.nextLine();
                    gistitemlist.editGist(itemnum-1,newname);
                    System.out.println("Success update gist");
                    break;
                    
                case 3:
                    System.out.println("");
                    System.out.println("===========");
                    System.out.println("Delete Gist");
                    System.out.println("===========");
                    System.out.println("Which gist do you want to remove : ");
                    gistitemlist.showGist();
                    itemnum = input.nextInt();
                    gistitemlist.deleteGist(itemnum-1);
                    break;
                    
                case 4:
                    System.out.println("");
                    System.out.println("=========");
                    System.out.println("Show Gist");
                    System.out.println("=========");
                    gistitemlist.showGist();
                    break;
                    
                case 5:
                    System.exit(0);
                    break;
                    
                default:
                    System.out.println("You choose the wrong option, please select another");
                    break;
            }
        }   
    }
}
