import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MainTest
{
    public MainTest()
    {
    }

    @Test
    public void testGist(){
        GistItemList gistitemlist = new GistItemList();
        
        //add
        gistitemlist.addGist("Jesslyn");
        gistitemlist.addGist("Maria");
        assertEquals("Jesslyn",gistitemlist.getGistItemAtIndex(0).toString());
        assertEquals("Maria",gistitemlist.getGistItemAtIndex(1).toString());
        
        //edit
        gistitemlist.editGist(0, "Jessica");
        assertEquals("Jessica",gistitemlist.getGistItemAtIndex(0).toString());
        assertEquals("Maria",gistitemlist.getGistItemAtIndex(1).toString());
        
        //delete
        gistitemlist.deleteGist(0);
        assertNotEquals("Jessica",gistitemlist.getGistItemAtIndex(0).toString());
        
    }
}
