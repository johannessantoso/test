public class GistItem
{
    private String name;

    public GistItem(String name)
    {
        // initialise instance variables
        this.name = name;
    }
    
    public void setName(String newname){
        this.name = newname;
    }
    
    public String toString()
    {
        return this.name;
    }
}
