import java.util.*;

public class GistItemList
{
    private ArrayList<GistItem> gistitemlist = null;
    
    public GistItemList()
    {
        gistitemlist = new ArrayList<GistItem>();
    }

    public void addGist(String name)
    {
        GistItem gist = new GistItem(name);
        gistitemlist.add(gist);
    }
    
    public void editGist(int index, String name){
        gistitemlist.get(index).setName(name);
    }
    
    public void showGist(){
        for(int i=0; i<gistitemlist.size(); i++){
            System.out.println((i+1) + " " + gistitemlist.get(i));
        }
    }
    
    public void deleteGist(int index){
        gistitemlist.remove(index);
    }
    
    public GistItem getGistItemAtIndex(int index){
        return gistitemlist.get(index);
    }
}
