package com.example.johannessantoso.appincreasebrightness;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //set permission
        if(!Settings.System.canWrite(this)){
            Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
            intent.setData(Uri.parse("package:" + this.getPackageName()));
            startActivity(intent);
        }
        tv = findViewById(R.id.textView);

        //prepare the click button
        Button button1 = (Button)findViewById(R.id.increaseBrightnessLevel);
        button1.setOnClickListener(this);

        for(int i=0; i<10; i++) {
            //initialization
            if(i==9) {
                int inc = 30;
                int brightness = Integer.parseInt(tv.getText().toString());

                //wait 1 second to perform click button
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                //add increment
                tv.setText(String.valueOf(inc + brightness));

                //perform click
                button1.performClick();
            }else{
                int inc = 25;
                int brightness = Integer.parseInt(tv.getText().toString());

                //wait 1 second to perform click button
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                //add increment
                tv.setText(String.valueOf(inc + brightness));

                //perform click
                button1.performClick();
            }
        }
    }

    @Override
    public void onClick(View v) {
        ContentResolver contentResolver = this.getApplicationContext().getContentResolver();
        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, Integer.parseInt(tv.getText().toString()));
    }
}

