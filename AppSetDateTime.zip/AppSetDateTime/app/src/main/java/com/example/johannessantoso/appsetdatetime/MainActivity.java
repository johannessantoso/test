package com.example.johannessantoso.appsetdatetime;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Date;
import java.util.Calendar;
import java.text.SimpleDateFormat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //set permission
        if(!Settings.System.canWrite(this)){
            Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
            intent.setData(Uri.parse("package:" + this.getPackageName()));
            startActivity(intent);
        }
        tv = findViewById(R.id.textView);

        //prepare the click button
        Button button1 = (Button)findViewById(R.id.setDateTime);
        button1.setOnClickListener(this);

        //wait 3 second to perform click button
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        button1.performClick();
    }


    @Override
    public void onClick(View v) {

        // 01-01-1900 11:59 PM

        // set new calendar date
        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        calendar.set(Calendar.MONTH, 0);
        calendar.set(Calendar.YEAR, 1900);
        calendar.set(Calendar.HOUR_OF_DAY, 11);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.AM_PM, 9);

        // create a date "formatter" that we want
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy hh:mm a");

        // create a new String using the date format we want
        String newformatdate = formatter.format(calendar.getTime());

        // set new formatted time that we want to textView
        tv.setText(String.valueOf(newformatdate));

        //ContentResolver contentResolver = this.getApplicationContext().getContentResolver();
        //Settings.System.putLong(contentResolver, Settings.System.DATE_FORMAT, Long.parseLong(tv.getText().toString()));
    }
}
