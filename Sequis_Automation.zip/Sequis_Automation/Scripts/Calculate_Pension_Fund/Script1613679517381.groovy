import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW

WebUI.openBrowser('')

WebUI.navigateToUrl(GlobalVariable.URL)

WebUI.maximizeWindow()

WebUI.delay(2)

WebUI.click(findTestObject('Home Page/mainmenu_asuransi_jiwa'))

WebUI.click(findTestObject('Home Page/submenu_dana_pensiun'))

WebUI.delay(2)

WebUI.verifyElementText(findTestObject('Home Page/text_dana_pensiun'), 'Dana Pensiun')

WebUI.scrollToPosition(999, 999)

WebUI.click(findTestObject('Page Dana Pensiun Main/combobox_choose'))

WebUI.click(findTestObject('Page Dana Pensiun Main/combobox_selection_dana_pensiun'))

WebUI.click(findTestObject('Page Dana Pensiun Main/button_selanjutnya'))

WebUI.delay(2)

WebUI.verifyElementPresent(findTestObject('Page Dana Pensiun Details/part1_text_hitung_penghasilan'), 5)

WebUI.sendKeys(findTestObject('Page Dana Pensiun Details/part1_textbox_ppb'), '10000000')

WebUI.clearText(findTestObject('Page Dana Pensiun Details/part1_textbox_inflasi'))

WebUI.sendKeys(findTestObject('Page Dana Pensiun Details/part1_textbox_inflasi'), '5')

WebUI.click(findTestObject('Page Dana Pensiun Details/part1_button_selanjutnya'))

WebUI.delay(2)

WebUI.verifyElementPresent(findTestObject('Page Dana Pensiun Details/part2_text_silahkan_isi'), 5)

WebUI.dragAndDropByOffset(findTestObject('Page Dana Pensiun Details/part2_slider_usia_saat_ini'), 50, 0)

WebUI.dragAndDropByOffset(findTestObject('Page Dana Pensiun Details/part2_slider_usia_pensiun'), 300, 0)

WebUI.click(findTestObject('Page Dana Pensiun Details/part2_button_selanjutnya'))

WebUI.delay(2)

WebUI.verifyElementPresent(findTestObject('Page Dana Pensiun Details/part3_text_gaya_hidup'), 5)

WebUI.dragAndDropByOffset(findTestObject('Page Dana Pensiun Details/part3_slider_rasio_penggantian'), 150, 0)

WebUI.click(findTestObject('Page Dana Pensiun Details/part3_button_selanjutnya'))

WebUI.delay(2)

WebUI.verifyElementPresent(findTestObject('Page Dana Pensiun Details/part4_text_jumlah_pemasukan'), 5)

WebUI.dragAndDropByOffset(findTestObject('Page Dana Pensiun Details/part4_slider_lama_pensiun'), 125, 0)

WebUI.clearText(findTestObject('Page Dana Pensiun Details/part4_textbox_suku_bunga_depo'))

WebUI.sendKeys(findTestObject('Page Dana Pensiun Details/part4_textbox_suku_bunga_depo'), '5')

WebUI.click(findTestObject('Page Dana Pensiun Details/part4_button_selanjutnya'))

WebUI.delay(2)

WebUI.verifyElementClickable(findTestObject('Page Final Result/button_dapatkan_hasil'), FailureHandling.STOP_ON_FAILURE)

WebUI.closeBrowser()

