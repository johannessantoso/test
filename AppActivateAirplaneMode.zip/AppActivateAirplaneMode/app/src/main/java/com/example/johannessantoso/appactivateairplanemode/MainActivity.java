package com.example.johannessantoso.appactivateairplanemode;

import android.Manifest;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //prepare the click button
        Button button1 = (Button)findViewById(R.id.AirplaneModeOn);
        button1.setOnClickListener(this);


        //wait 3 second to perform click button
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        button1.performClick();

    }

    @Override
    public void onClick(View v) {
        // get the airplane mode setting
        boolean isEnabled = Settings.Global.getInt(
                getContentResolver(),
                Settings.Global.AIRPLANE_MODE_ON, 0) == 1;

        // set the airplane mode setting to ON
        Settings.Global.putInt(
                getContentResolver(),
                Settings.Global.AIRPLANE_MODE_ON, isEnabled ? 0 : 1);
    }
}
